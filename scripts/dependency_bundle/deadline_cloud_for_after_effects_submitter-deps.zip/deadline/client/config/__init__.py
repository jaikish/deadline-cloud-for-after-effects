# Copyright Amazon.com, Inc. or its affiliates. All Rights Reserved.

"""
This module encapsulates the configuration of [AWS Deadline Cloud] on a workstation.

By default, configuration is stored in `~/.deadline/config`. If a user sets
the environment variable DEADLINE_CONFIG_FILE_PATH, it is used as the configuration
file path instead.

[AWS Deadline Cloud]: https://aws.amazon.com/deadline-cloud/
"""

__all__ = [
    "get_setting_default",
    "get_setting",
    "set_setting",
    "clear_setting",
    "get_best_profile_for_farm",
    "str2bool",
    "DEFAULT_DEADLINE_ENDPOINT_URL",
]

from .config_file import (
    DEFAULT_DEADLINE_ENDPOINT_URL,
    get_best_profile_for_farm,
    get_setting,
    get_setting_default,
    set_setting,
    clear_setting,
    str2bool,
)
